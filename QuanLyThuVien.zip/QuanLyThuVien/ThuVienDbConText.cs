﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
namespace QuanLyThuVien
{
    public class ThuVienDbConText: DbContext
    {
        public DbSet<TheLoaiSach> TheLoaiSach { get; set; }
        public DbSet<FormAdmin> Admin { get; set; }
        public DbSet<Book> Book { get; set; }
        public DbSet<NguoiDung> NguoiDung { get; set; }
    }
}
