﻿namespace QuanLyThuVien
{
    partial class QLTheLoai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QLTheLoai));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.txtTkTheLoai = new System.Windows.Forms.TextBox();
            this.dataTheLoai = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMaTheLoai = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTenTheLoai = new System.Windows.Forms.TextBox();
            this.btnThemTL = new System.Windows.Forms.Button();
            this.btnXoaTL = new System.Windows.Forms.Button();
            this.btnSuaTL = new System.Windows.Forms.Button();
            this.btnLuuTL = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataTheLoai)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(273, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(218, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Quản Lý Thể Loại";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(488, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(175, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tìm kiếm thể loại";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(420, 136);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(108, 20);
            this.radioButton1.TabIndex = 2;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Tên Thể Loại";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(627, 136);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(103, 20);
            this.radioButton2.TabIndex = 3;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Mã Thể Loại";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // txtTkTheLoai
            // 
            this.txtTkTheLoai.Location = new System.Drawing.Point(424, 171);
            this.txtTkTheLoai.Name = "txtTkTheLoai";
            this.txtTkTheLoai.Size = new System.Drawing.Size(315, 22);
            this.txtTkTheLoai.TabIndex = 4;
            // 
            // dataTheLoai
            // 
            this.dataTheLoai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataTheLoai.Location = new System.Drawing.Point(406, 207);
            this.dataTheLoai.Name = "dataTheLoai";
            this.dataTheLoai.RowHeadersWidth = 51;
            this.dataTheLoai.RowTemplate.Height = 24;
            this.dataTheLoai.Size = new System.Drawing.Size(382, 231);
            this.dataTheLoai.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(85, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(189, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Cập nhật thông tin";
            // 
            // txtMaTheLoai
            // 
            this.txtMaTheLoai.Location = new System.Drawing.Point(118, 136);
            this.txtMaTheLoai.Name = "txtMaTheLoai";
            this.txtMaTheLoai.Size = new System.Drawing.Size(213, 22);
            this.txtMaTheLoai.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Mã Thể Loại";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 176);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Tên Thể Loại";
            // 
            // txtTenTheLoai
            // 
            this.txtTenTheLoai.Location = new System.Drawing.Point(118, 170);
            this.txtTenTheLoai.Name = "txtTenTheLoai";
            this.txtTenTheLoai.Size = new System.Drawing.Size(213, 22);
            this.txtTenTheLoai.TabIndex = 10;
            // 
            // btnThemTL
            // 
            this.btnThemTL.Location = new System.Drawing.Point(19, 231);
            this.btnThemTL.Name = "btnThemTL";
            this.btnThemTL.Size = new System.Drawing.Size(132, 55);
            this.btnThemTL.TabIndex = 11;
            this.btnThemTL.Text = "Thêm";
            this.btnThemTL.UseVisualStyleBackColor = true;
            // 
            // btnXoaTL
            // 
            this.btnXoaTL.Location = new System.Drawing.Point(202, 231);
            this.btnXoaTL.Name = "btnXoaTL";
            this.btnXoaTL.Size = new System.Drawing.Size(128, 55);
            this.btnXoaTL.TabIndex = 12;
            this.btnXoaTL.Text = "Xoá";
            this.btnXoaTL.UseVisualStyleBackColor = true;
            // 
            // btnSuaTL
            // 
            this.btnSuaTL.Location = new System.Drawing.Point(26, 320);
            this.btnSuaTL.Name = "btnSuaTL";
            this.btnSuaTL.Size = new System.Drawing.Size(124, 54);
            this.btnSuaTL.TabIndex = 13;
            this.btnSuaTL.Text = "Sửa";
            this.btnSuaTL.UseVisualStyleBackColor = true;
            // 
            // btnLuuTL
            // 
            this.btnLuuTL.Location = new System.Drawing.Point(207, 322);
            this.btnLuuTL.Name = "btnLuuTL";
            this.btnLuuTL.Size = new System.Drawing.Size(123, 51);
            this.btnLuuTL.TabIndex = 14;
            this.btnLuuTL.Text = "Lưu";
            this.btnLuuTL.UseVisualStyleBackColor = true;
            // 
            // QLTheLoai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLuuTL);
            this.Controls.Add(this.btnSuaTL);
            this.Controls.Add(this.btnXoaTL);
            this.Controls.Add(this.btnThemTL);
            this.Controls.Add(this.txtTenTheLoai);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtMaTheLoai);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataTheLoai);
            this.Controls.Add(this.txtTkTheLoai);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "QLTheLoai";
            this.Text = "QLTheLoai";
            this.Load += new System.EventHandler(this.QLTheLoai_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataTheLoai)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.TextBox txtTkTheLoai;
        private System.Windows.Forms.DataGridView dataTheLoai;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMaTheLoai;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTenTheLoai;
        private System.Windows.Forms.Button btnThemTL;
        private System.Windows.Forms.Button btnXoaTL;
        private System.Windows.Forms.Button btnSuaTL;
        private System.Windows.Forms.Button btnLuuTL;
    }
}