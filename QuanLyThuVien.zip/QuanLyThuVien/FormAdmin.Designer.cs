﻿namespace QuanLyThuVien
{
    partial class FormAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuQLNguoiDung = new System.Windows.Forms.ToolStripMenuItem();
            this.menuQLPhieu = new System.Windows.Forms.ToolStripMenuItem();
            this.menuPhieuMuon = new System.Windows.Forms.ToolStripMenuItem();
            this.menuPhieuTra = new System.Windows.Forms.ToolStripMenuItem();
            this.menuTheLoai = new System.Windows.Forms.ToolStripMenuItem();
            this.menuTaiKhoan = new System.Windows.Forms.ToolStripMenuItem();
            this.menuQLSach = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuLuaChon = new System.Windows.Forms.ToolStripMenuItem();
            this.menuVeDangNhap = new System.Windows.Forms.ToolStripMenuItem();
            this.menuThoat = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuQLNguoiDung,
            this.menuQLPhieu,
            this.menuTheLoai,
            this.menuTaiKhoan,
            this.menuQLSach,
            this.menuLuaChon});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(856, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuQLNguoiDung
            // 
            this.menuQLNguoiDung.Name = "menuQLNguoiDung";
            this.menuQLNguoiDung.Size = new System.Drawing.Size(157, 24);
            this.menuQLNguoiDung.Text = "Quản lý Người dùng";
            // 
            // menuQLPhieu
            // 
            this.menuQLPhieu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuPhieuMuon,
            this.menuPhieuTra});
            this.menuQLPhieu.Name = "menuQLPhieu";
            this.menuQLPhieu.Size = new System.Drawing.Size(113, 24);
            this.menuQLPhieu.Text = "Quản lý Phiếu";
            // 
            // menuPhieuMuon
            // 
            this.menuPhieuMuon.Name = "menuPhieuMuon";
            this.menuPhieuMuon.Size = new System.Drawing.Size(224, 26);
            this.menuPhieuMuon.Text = "Phiếu Mượn";
            // 
            // menuPhieuTra
            // 
            this.menuPhieuTra.Name = "menuPhieuTra";
            this.menuPhieuTra.Size = new System.Drawing.Size(224, 26);
            this.menuPhieuTra.Text = "Phiếu Trả";
            // 
            // menuTheLoai
            // 
            this.menuTheLoai.Name = "menuTheLoai";
            this.menuTheLoai.Size = new System.Drawing.Size(127, 24);
            this.menuTheLoai.Text = "Quản lý thể loại";
            this.menuTheLoai.Click += new System.EventHandler(this.menuTheLoai_Click);
            // 
            // menuTaiKhoan
            // 
            this.menuTaiKhoan.Name = "menuTaiKhoan";
            this.menuTaiKhoan.Size = new System.Drawing.Size(151, 24);
            this.menuTaiKhoan.Text = "Thông tin tài khoản";
            // 
            // menuQLSach
            // 
            this.menuQLSach.Name = "menuQLSach";
            this.menuQLSach.Size = new System.Drawing.Size(106, 24);
            this.menuQLSach.Text = "Quản lý sách";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // menuLuaChon
            // 
            this.menuLuaChon.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuVeDangNhap,
            this.menuThoat});
            this.menuLuaChon.Name = "menuLuaChon";
            this.menuLuaChon.Size = new System.Drawing.Size(83, 24);
            this.menuLuaChon.Text = "Lựa chọn";
            // 
            // menuVeDangNhap
            // 
            this.menuVeDangNhap.Name = "menuVeDangNhap";
            this.menuVeDangNhap.Size = new System.Drawing.Size(224, 26);
            this.menuVeDangNhap.Text = "Trở về Đăng nhập";
            // 
            // menuThoat
            // 
            this.menuThoat.Name = "menuThoat";
            this.menuThoat.Size = new System.Drawing.Size(224, 26);
            this.menuThoat.Text = "Thoát";
            // 
            // FormAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormAdmin";
            this.Text = "FormAdmin";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuQLNguoiDung;
        private System.Windows.Forms.ToolStripMenuItem menuQLPhieu;
        private System.Windows.Forms.ToolStripMenuItem menuPhieuMuon;
        private System.Windows.Forms.ToolStripMenuItem menuPhieuTra;
        private System.Windows.Forms.ToolStripMenuItem menuTheLoai;
        private System.Windows.Forms.ToolStripMenuItem menuTaiKhoan;
        private System.Windows.Forms.ToolStripMenuItem menuQLSach;
        private System.Windows.Forms.ToolStripMenuItem menuLuaChon;
        private System.Windows.Forms.ToolStripMenuItem menuVeDangNhap;
        private System.Windows.Forms.ToolStripMenuItem menuThoat;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    }
}