﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            // Hiển thị hộp thoại xác nhận có muốn huỷ không
            DialogResult result = MessageBox.Show("Bạn có muốn huỷ không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // Kiểm tra kết quả từ hộp thoại xác nhận
            if (result == DialogResult.Yes)
            {
                // Xử lý khi người dùng chọn "Có"
                // Đóng cửa sổ hoặc thực hiện hành động phù hợp
                this.Close();
            }
            else
            {
                // Xử lý khi người dùng chọn "Không" hoặc đóng hộp thoại
                // Thực hiện hành động phù hợp nếu cần thiết
            }
        }

        private void btnDangnhap_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem RadioButton nào được chọn
            if (rdAdmin.Checked)
            {
                // Xử lý đăng nhập cho quyền Admin
                // Ví dụ:
                MessageBox.Show("Đăng nhập với quyền Admin");
                //Ẩn form
                this.Hide();
                // Thực hiện hành động phù hợp cho quyền Admin
                FormAdmin formAdmin = new FormAdmin();
                formAdmin.ShowDialog();
                
                
            }
            else if (rdUser.Checked)
            {
                // Xử lý đăng nhập cho quyền User
                // Ví dụ:
                MessageBox.Show("Đăng nhập với quyền User");
                // Thực hiện hành động phù hợp cho quyền User
            }
            else
            {
                MessageBox.Show("Vui lòng chọn quyền đăng nhập");
                // Hiển thị thông báo nếu không có RadioButton nào được chọn
            }
        }
    }
}
