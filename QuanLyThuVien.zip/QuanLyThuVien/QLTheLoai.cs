﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien
{
    public partial class QLTheLoai : Form
    {
        public QLTheLoai()
        {
            InitializeComponent();
        }

        private void QLTheLoai_Load(object sender, EventArgs e)
        {
            using (var context = new ThuVienDbConText())
            {
                // Lấy danh sách các thể loại sách từ bảng TheLoaiSach
                var theLoaiList = context.TheLoaiSach.ToList();

                // Hiển thị dữ liệu lấy được vào DataGridView
                dataTheLoai.DataSource = theLoaiList;
            }

        }
    }
}
